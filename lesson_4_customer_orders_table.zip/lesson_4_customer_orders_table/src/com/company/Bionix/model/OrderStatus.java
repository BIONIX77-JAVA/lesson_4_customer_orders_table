package com.company.Bionix.model;

public enum OrderStatus {
    Paid,
    Shipping,
    Completed,
    DeliveryExpected,
}